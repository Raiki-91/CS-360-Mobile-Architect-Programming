package com.zybooks.leekitchenproject2option3;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.zybooks.leekitchenproject2option3.DatabaseHelper;
import com.zybooks.leekitchenproject2option3.R;

import java.util.ArrayList;
import java.util.Calendar;

public class EventActivity extends Activity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    private ListView listViewEvents;
    private Button buttonAddEvent;
    private ArrayList<String> eventList;
    private ArrayAdapter<String> eventAdapter;

    private DatabaseHelper databaseHelper;
    private int editPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_activity);

        listViewEvents = findViewById(R.id.listViewEvents);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);

        databaseHelper = new DatabaseHelper(this);

        eventList = new ArrayList<>();
        eventAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventList);
        listViewEvents.setAdapter(eventAdapter);

        buttonAddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddEventDialog(false, null, null, null);
            }
        });

        listViewEvents.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String[] eventDetails = eventList.get(position).split(" - | at ");
                editPosition = position;
                showAddEventDialog(true, eventDetails[0], eventDetails[1], eventDetails[2]);
            }
        });

        listViewEvents.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                confirmDeleteEvent(position);
                return true;
            }
        });

        // Load saved events
        loadEvents();
    }

    private void showAddEventDialog(final boolean isEdit, String eventName, String eventDate, String eventTime) {
        // Inflate the layout for the dialog
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_add_event, null);

        final EditText editTextEventName = dialogView.findViewById(R.id.editTextEventName);
        final EditText editTextEventDate = dialogView.findViewById(R.id.editTextEventDate);
        final EditText editTextEventTime = dialogView.findViewById(R.id.editTextEventTime);

        if (isEdit && eventName != null && eventDate != null && eventTime != null) {
            editTextEventName.setText(eventName);
            editTextEventDate.setText(eventDate);
            editTextEventTime.setText(eventTime);
        }

        // Set the current date and time by default
        Calendar calendar = Calendar.getInstance();
        if (!isEdit) {
            editTextEventDate.setText(String.format("%02d/%02d/%04d", calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.YEAR)));
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            editTextEventTime.setText(String.format("%02d:%02d %s", (hour % 12 == 0) ? 12 : hour % 12, minute, (hour >= 12) ? "PM" : "AM"));
        }

        editTextEventDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(EventActivity.this,
                        (view, selectedYear, selectedMonth, selectedDay) -> {
                            editTextEventDate.setText(String.format("%02d/%02d/%04d", selectedMonth + 1, selectedDay, selectedYear));
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        editTextEventTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog = new TimePickerDialog(EventActivity.this,
                        (view, hourOfDay, selectedMinute) -> {
                            String period = (hourOfDay >= 12) ? "PM" : "AM";
                            int hourIn12HourFormat = (hourOfDay % 12 == 0) ? 12 : hourOfDay % 12;
                            editTextEventTime.setText(String.format("%02d:%02d %s", hourIn12HourFormat, selectedMinute, period));
                        }, hour, minute, false); // 'false' indicates 12-hour clock
                timePickerDialog.show();
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isEdit ? "Edit Event" : "Add New Event")
                .setView(dialogView)
                .setPositiveButton(isEdit ? "Update" : "Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newEventName = editTextEventName.getText().toString().trim();
                        String newEventDate = editTextEventDate.getText().toString().trim();
                        String newEventTime = editTextEventTime.getText().toString().trim();

                        if (newEventName.isEmpty() || newEventDate.isEmpty() || newEventTime.isEmpty()) {
                            Toast.makeText(EventActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                        } else {
                            String eventDetails = newEventName + " - " + newEventDate + " at " + newEventTime;
                            if (isEdit) {
                                // Update the event in the list
                                eventList.set(editPosition, eventDetails);
                                eventAdapter.notifyDataSetChanged();

                                // Update the event in the database
                                databaseHelper.updateEvent(eventList.get(editPosition), newEventName, newEventDate, newEventTime);
                                Toast.makeText(EventActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                            } else {
                                eventList.add(eventDetails);
                                eventAdapter.notifyDataSetChanged();

                                // Save new event to Database
                                databaseHelper.addEvent(newEventName, newEventDate, newEventTime);

                                // Check for SMS permission
                                if (ContextCompat.checkSelfPermission(EventActivity.this, android.Manifest.permission.SEND_SMS)
                                        == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                    sendSMSNotification(eventDetails);
                                } else {
                                    ActivityCompat.requestPermissions(EventActivity.this,
                                            new String[]{android.Manifest.permission.SEND_SMS},
                                            SMS_PERMISSION_REQUEST_CODE);
                                }

                                Toast.makeText(EventActivity.this, "Event added", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    private void confirmDeleteEvent(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Event")
                .setMessage("Are you sure you want to delete this event?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String eventDetails = eventList.get(position);
                        eventList.remove(position);
                        eventAdapter.notifyDataSetChanged();
                        // Delete event from database
                        String[] details = eventDetails.split(" - | at ");
                        databaseHelper.deleteEvent(details[0], details[1], details[2]);
                        Toast.makeText(EventActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    private void loadEvents() {
        Cursor cursor = databaseHelper.getAllEvents();
        eventList.clear();
        if (cursor.moveToFirst()) {
            do {
                String eventName = cursor.getString(0);
                String eventDate = cursor.getString(1);
                String eventTime = cursor.getString(2);
                String eventDetails = eventName + " - " + eventDate + " at " + eventTime;
                eventList.add(eventDetails);
            } while (cursor.moveToNext());
        }
        cursor.close();
        eventAdapter.notifyDataSetChanged();
    }

    private void sendSMSNotification(String eventDetails) {
        // Replace with actual phone number for testing
        String phoneNumber = "1234567890";
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, "Reminder: " + eventDetails, null, null);
        Toast.makeText(this, "SMS notification sent", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                if (!eventList.isEmpty()) {
                    sendSMSNotification(eventList.get(eventList.size() - 1)); // send SMS for the last added event
                }
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied. Unable to send notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
