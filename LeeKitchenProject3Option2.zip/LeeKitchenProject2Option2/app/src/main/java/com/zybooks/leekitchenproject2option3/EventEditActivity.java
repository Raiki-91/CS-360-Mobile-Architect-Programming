package com.zybooks.leekitchenproject2option3;

import android.app.Activity;
import android.os.Bundle;

public class EventEditActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_edit_activity);

    }
}
