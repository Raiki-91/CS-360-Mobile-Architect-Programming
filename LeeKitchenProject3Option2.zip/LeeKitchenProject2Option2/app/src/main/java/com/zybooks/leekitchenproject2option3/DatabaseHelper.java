package com.zybooks.leekitchenproject2option3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "events.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_EVENTS = "events";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EVENT_NAME = "event_name";
    private static final String COLUMN_EVENT_DATE = "event_date";
    private static final String COLUMN_EVENT_TIME = "event_time";

    // User table for authentication
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EVENT_NAME + " TEXT, " +
                COLUMN_EVENT_DATE + " TEXT, " +
                COLUMN_EVENT_TIME + " TEXT)";
        db.execSQL(createEventsTable);

        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Method to add an event to the database
    public boolean addEvent(String eventName, String eventDate, String eventTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_EVENT_DATE, eventDate);
        values.put(COLUMN_EVENT_TIME, eventTime);

        long result = db.insert(TABLE_EVENTS, null, values);
        db.close();

        return result != -1; // returns true if insert was successful
    }

    // Method to get all events from the database
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT " + COLUMN_EVENT_NAME + ", " + COLUMN_EVENT_DATE + ", " + COLUMN_EVENT_TIME + " FROM " + TABLE_EVENTS, null);
    }

    // Method to delete an event from the database
    public boolean deleteEvent(String eventName, String detail, String s) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_EVENTS, COLUMN_EVENT_NAME + " = ?", new String[]{eventName});
        db.close();

        return result > 0; // returns true if deletion was successful
    }

    // Method to update an existing event in the database
    public void updateEvent(String oldEventDetails, String newEventName, String newEventDate, String newEventTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("event_name", newEventName);
        values.put("event_date", newEventDate);
        values.put("event_time", newEventTime);
        String[] eventDetails = oldEventDetails.split(" - | at ");
        db.update("events", values, "event_name=? AND event_date=? AND event_time=?", new String[]{eventDetails[0], eventDetails[1], eventDetails[2]});
    }


    // Method to add a user to the database
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1; // returns true if insert was successful
    }

    // Method to check if a user exists in the database
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID},
                COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close();
        return exists; // returns true if user exists with the provided username and password
    }

    // Optional method to get a specific event (used in the edit functionality)
    public Cursor getEvent(String eventName) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT " + COLUMN_EVENT_NAME + ", " + COLUMN_EVENT_DATE + ", " + COLUMN_EVENT_TIME + " FROM " + TABLE_EVENTS + " WHERE " + COLUMN_EVENT_NAME + " = ?", new String[]{eventName});
    }
}
